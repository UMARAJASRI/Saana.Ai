import React, { useState } from 'react';
import { 
  Battery, 
  Zap, 
  Car, 
  LayoutDashboard, 
  TrendingUp, 
  AlertTriangle, 
  BarChart3, 
  Calculator, 
  MapPin, 
  Info,
  CheckCircle,
  ArrowRight
} from 'lucide-react';

const chargingData = [
  { hour: '00', demand: 120 }, { hour: '04', demand: 80 },
  { hour: '08', demand: 450 }, { hour: '12', demand: 320 },
  { hour: '16', demand: 400 }, { hour: '20', demand: 680 },
  { hour: '23', demand: 200 }
];

const fleetVehicles = [
  { id: 'T-001', model: 'Model A', soc: 85, range: 340, status: 'Healthy' },
  { id: 'T-002', model: 'Model B', soc: 42, range: 120, status: 'Warning' },
  { id: 'T-003', model: 'Model A', soc: 92, range: 380, status: 'Healthy' },
  { id: 'T-004', model: 'Model C', soc: 60, range: 210, status: 'Optimal' },
];

const carModels = [
  { name: 'EV Sedan Pro', range: 450, cost: 42000, efficiency: 15.2, emissions: 0 },
  { name: 'City Compact', range: 280, cost: 28000, efficiency: 12.5, emissions: 0 },
  { name: 'SUV Voyager', range: 520, cost: 55000, efficiency: 18.9, emissions: 0 },
];

const Card = ({ children, className = "" }) => (
  <div className={`bg-white rounded-xl shadow-sm border border-slate-200 p-6 ${className}`}>
    {children}
  </div>
);

const Badge = ({ status }) => {
  const styles = {
    'Healthy': 'bg-green-100 text-green-700',
    'Warning': 'bg-red-100 text-red-700',
    'Optimal': 'bg-blue-100 text-blue-700'
  };
  return <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status]}`}>{status}</span>;
};

const EnergyPlanner = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card>
        <h3 className="text-sm text-slate-500 font-medium">Peak Demand</h3>
        <p className="text-3xl font-bold mt-2">680 <span className="text-sm font-normal text-slate-400">kWh/h</span></p>
      </Card>
      <Card>
        <h3 className="text-sm text-slate-500 font-medium">Active Chargers</h3>
        <p className="text-3xl font-bold mt-2">1,240</p>
      </Card>
      <Card>
        <h3 className="text-sm text-slate-500 font-medium">Grid Load Stability</h3>
        <p className="text-3xl font-bold mt-2 text-green-600">98.2%</p>
      </Card>
    </div>

    <Card>
      <h2 className="text-lg font-bold mb-6">Daily Charging Demand Profile</h2>
      <div className="h-64 flex items-end justify-between gap-4">
        {chargingData.map((d) => (
          <div key={d.hour} className="flex flex-col items-center flex-1">
            <div 
              className="w-full bg-indigo-500 rounded-t-lg transition-all hover:bg-indigo-600"
              style={{ height: `${(d.demand / 700) * 100}%` }}
            />
            <span className="text-xs text-slate-400 mt-2">{d.hour}:00</span>
          </div>
        ))}
      </div>
    </Card>
  </div>
);

const FleetManager = () => (
  <Card>
    <div className="flex justify-between items-center mb-6">
      <h2 className="text-lg font-bold">Fleet Battery Health</h2>
      <button className="flex items-center text-sm text-indigo-600 font-medium hover:underline">
        <AlertTriangle className="w-4 h-4 mr-1" /> View Maintenance Alerts
      </button>
    </div>
    <div className="overflow-x-auto">
      <table className="w-full text-left">
        <thead>
          <tr className="text-slate-400 text-sm border-b">
            <th className="pb-3">Vehicle ID</th>
            <th className="pb-3">Model</th>
            <th className="pb-3">State of Charge</th>
            <th className="pb-3">Est. Range</th>
            <th className="pb-3">Status</th>
          </tr>
        </thead>
        <tbody>
          {fleetVehicles.map(v => (
            <tr key={v.id} className="border-b last:border-0 hover:bg-slate-50">
              <td className="py-4 font-medium">{v.id}</td>
              <td className="py-4 text-slate-600">{v.model}</td>
              <td className="py-4">
                <div className="w-24 h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500" style={{ width: `${v.soc}%` }} />
                </div>
              </td>
              <td className="py-4 text-slate-600">{v.range} km</td>
              <td className="py-4"><Badge status={v.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </Card>
);

const EVComparator = () => (
  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
    {carModels.map(car => (
      <Card key={car.name} className="flex flex-col">
        <h3 className="text-xl font-bold text-slate-800">{car.name}</h3>
        <div className="mt-4 space-y-3 flex-grow">
          <div className="flex justify-between text-sm"><span>Range:</span><span className="font-semibold">{car.range} km</span></div>
          <div className="flex justify-between text-sm"><span>Cost:</span><span className="font-semibold">${car.cost.toLocaleString()}</span></div>
          <div className="flex justify-between text-sm"><span>Efficiency:</span><span className="font-semibold">{car.efficiency} kWh/100km</span></div>
        </div>
        <button className="mt-6 w-full py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors flex items-center justify-center gap-2">
          Compare Details <ArrowRight className="w-4 h-4" />
        </button>
      </Card>
    ))}
  </div>
);

export default function App() {
  const [activeTab, setActiveTab] = useState('planner');

  const tabs = [
    { id: 'planner', label: 'Energy Planner', icon: MapPin },
    { id: 'fleet', label: 'Fleet Manager', icon: Battery },
    { id: 'compare', label: 'Model Comparator', icon: Calculator },
  ];

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">EV Insights & Analytics</h1>
          <p className="text-slate-500">Data-driven solutions for the electric transportation revolution.</p>
        </header>

        <nav className="flex gap-2 mb-8 bg-white p-1 rounded-xl shadow-sm border border-slate-200">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-medium transition-all ${
                activeTab === tab.id 
                ? 'bg-indigo-600 text-white shadow-md' 
                : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </nav>

        <main>
          {activeTab === 'planner' && <EnergyPlanner />}
          {activeTab === 'fleet' && <FleetManager />}
          {activeTab === 'compare' && <EVComparator />}
        </main>
      </div>
    </div>
  );
}