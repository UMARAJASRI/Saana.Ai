EV DATA ANALYTICS & VISUALIZATION PLATFORM
=========================================
TEAM MEMBERS:
- Ammula Durga Prasad (Team Lead)
- Ketha Lohitha
- Vella Chaitanya
- Baba Sai Nakka
- Yaswanth Rayudu

PROJECT METRICS:
- Total Epics: 8
- Total Tasks/Stories: 15
- Total Subtasks: 8

HOW TO RUN THE INTEGRATED FLASK APPLICATION:
1. Ensure Python 3 is installed.
2. Install Flask if not already installed via pip:
   pip install Flask
3. Run the app template file:
   python app.py
4. Navigate to http://127.0.0.1:5000/ in your browser.

DASHBOARD DESIGN PROFILE:
- Aesthetic: Cyberpunk / Sci-Fi HUD
- Primary Accents: Neon Cyan (#00f2fe) / Electric Blue (#4facfe)
- Visual Style: Glassmorphic panel layouts with dark backgrounds.
