from flask import Flask, render_template, render_template_string

app = Flask(__name__)

# Cyberpunk-inspired base layout matching the user's signature aesthetic
BASE_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{{ title }} - EV Analytics Platform</title>
    <style>
        body {
            background-color: #0a0f1d;
            color: #c3ccdb;
            font-family: 'Segoe UI', Roboto, Helvetica, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .hud-panel {
            background: rgba(16, 24, 48, 0.75);
            border: 1px solid #00f2fe;
            box-shadow: 0 0 15px rgba(0, 242, 254, 0.2);
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 25px;
            backdrop-filter: blur(10px);
        }
        h1, h2, h3 {
            color: #00f2fe;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 0;
            text-shadow: 0 0 10px rgba(0, 242, 254, 0.4);
        }
        .nav-bar {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
        }
        .nav-btn {
            background: transparent;
            border: 1px solid #4facfe;
            color: #4facfe;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .nav-btn:hover, .nav-btn.active {
            background: linear-gradient(135deg, #00f2fe 0%, #4facfe 100%);
            color: #0a0f1d;
            box-shadow: 0 0 15px rgba(0, 242, 254, 0.5);
        }
        .tableau-placeholder {
            width: 100%;
            height: 600px;
            background: rgba(10, 15, 30, 0.6);
            border: 1px dashed #4facfe;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            color: #4facfe;
            font-family: monospace;
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .stat-card {
            background: rgba(20, 30, 60, 0.6);
            border-left: 4px solid #00f2fe;
            padding: 15px;
            border-radius: 0 6px 6px 0;
        }
    </style>
</head>
<body>
    <div class="hud-panel">
        <h1>EV Data Analytics Control Center</h1>
        <div class="nav-bar">
            <a href="/" class="nav-btn">System Overview</a>
            <a href="/charging_analysis" class="nav-btn">Grid Demand (Scenario 1)</a>
            <a href="/fleet_performance" class="nav-btn">Battery Health (Scenario 2)</a>
            <a href="/model_comparison" class="nav-btn">Model Efficiency (Scenario 3)</a>
        </div>
        {% block content %}{% endblock %}
    </div>
</body>
</html>
'''

OVERVIEW_CONTENT = '''
{% extends "base" %}
{% block content %}
    <h2>System Overview Dashboard</h2>
    <p>Welcome to the Electric Vehicle multi-tier analysis ecosystem node. Select a specialized module above to load live views.</p>
    <div class="grid-container">
        <div class="stat-card">
            <h3>Epics Tracking</h3>
            <p>8 Core Epics Configured</p>
        </div>
        <div class="stat-card">
            <h3>Sprint Tasks</h3>
            <p>15 Active Stories / Subtasks</p>
        </div>
        <div class="stat-card">
            <h3>Data Pipeline</h3>
            <p>SQL Engine Stack Ready</p>
        </div>
    </div>
{% endblock %}
'''

TABLEAU_TEMPLATE = '''
{% extends "base" %}
{% block content %}
    <h2>{{ scenario_title }}</h2>
    <p>{{ description }}</p>
    <div class="tableau-placeholder">
        <!-- TABLEAU EMBED INTERFACE -->
        [ TABLEAU DASHBOARD EMBED ELEMENT LIVE ]<br>
        Target URL: https://public.tableau.com/views/{{ workbook_id }}<br>
        Status: Secure Iframe Container Operational via Flask Controller
    </div>
{% endblock %}
'''

@app.route('/')
def index():
    return render_template_string(OVERVIEW_CONTENT, title="System Node Overview")

@app.route('/charging_analysis')
def charging_analysis():
    return render_template_string(TABLEAU_TEMPLATE, 
                                  title="Grid Allocation Analysis",
                                  scenario_title="Scenario 1: Charging Patterns & Grid Demand Heatmaps",
                                  description="Aarav's Command: Monitoring localized energy distribution profiles.",
                                  workbook_id="EV_Charging_Patterns_Grid_Demand")

@app.route('/fleet_performance')
def fleet_performance():
    return render_template_string(TABLEAU_TEMPLATE, 
                                  title="Fleet Diagnostics Engine",
                                  scenario_title="Scenario 2: Battery Longevity vs Realized Driving Range",
                                  description="Meera's Command: Predicting degradation scales, SoC profiles, and life cycles.",
                                  workbook_id="EV_Fleet_Battery_Performance_Lifecycle")

@app.route('/model_comparison')
def model_comparison():
    return render_template_string(TABLEAU_TEMPLATE, 
                                  title="Model Comparison Matrix",
                                  scenario_title="Scenario 3: Multi-Variant Model Efficiency Comparison",
                                  description="Ravi's Command: Cost-per-kilometer profiling, fuel offsets, and emissions data.",
                                  workbook_id="EV_Model_Efficiency_Comparison_Matrix")

if __name__ == '__main__':
    app.run(debug=True)
